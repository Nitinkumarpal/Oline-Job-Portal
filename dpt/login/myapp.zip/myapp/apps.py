from django.apps import AppConfig


class Login1Config(AppConfig):
    name = 'myapp'
